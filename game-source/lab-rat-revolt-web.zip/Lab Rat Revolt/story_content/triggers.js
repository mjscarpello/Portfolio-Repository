function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5eRnSTNYDzM":
        Script1();
        break;
      case "61urV9jl2iN":
        Script2();
        break;
      case "61nW6y51TwM":
        Script3();
        break;
      case "62zwUOKz98E":
        Script4();
        break;
      case "5wLH7RbqVW0":
        Script5();
        break;
      case "60lTiSm2b9U":
        Script6();
        break;
      case "5VQJ6eKfDXL":
        Script7();
        break;
      case "6ptTieAmmqm":
        Script8();
        break;
      case "5cefSFDn2ur":
        Script9();
        break;
      case "5k8IKb1L8gP":
        Script10();
        break;
      case "6eSEikYfXG8":
        Script11();
        break;
      case "6mXUBjBHm4t":
        Script12();
        break;
      case "62CjCBdVkL6":
        Script13();
        break;
      case "6pKGVRnpZ76":
        Script14();
        break;
      case "5Y2aUp2ZcVF":
        Script15();
        break;
      case "5bF9mqMaFBl":
        Script16();
        break;
      case "6gKcIpyfOHy":
        Script17();
        break;
      case "5psc61xCYfH":
        Script18();
        break;
      case "6pWSCOYRuhD":
        Script19();
        break;
      case "6g7n5cR6aiV":
        Script20();
        break;
      case "5VfHnUK2Uur":
        Script21();
        break;
      case "6M6n7Bf0nVf":
        Script22();
        break;
      case "5rOn9ObypVQ":
        Script23();
        break;
      case "6pNQR7D1iG8":
        Script24();
        break;
      case "5jKXCMdcjkM":
        Script25();
        break;
      case "6NZelFIjzq1":
        Script26();
        break;
      case "5xiuTZjK0iW":
        Script27();
        break;
      case "699rCAYxgPu":
        Script28();
        break;
      case "5wDd2mzyh2S":
        Script29();
        break;
      case "6Ytk2LHCNeo":
        Script30();
        break;
      case "5ekuQ0sVOUx":
        Script31();
        break;
      case "624jmkGkClK":
        Script32();
        break;
      case "5vG914Whiz6":
        Script33();
        break;
      case "6JDC12qOBsv":
        Script34();
        break;
      case "6AmCbY6R7CH":
        Script35();
        break;
      case "5at78MA18Tn":
        Script36();
        break;
      case "6Kos4ELAjFc":
        Script37();
        break;
      case "6YjC9zPhs8W":
        Script38();
        break;
      case "6DJAv0PQnFR":
        Script39();
        break;
      case "6gzCDHV1IzN":
        Script40();
        break;
      case "5otwpVwuEgx":
        Script41();
        break;
      case "66ZWkZiz0pY":
        Script42();
        break;
      case "6fe13GsL9Cz":
        Script43();
        break;
      case "69jnPYE7zrj":
        Script44();
        break;
      case "5dseNuIV2gv":
        Script45();
        break;
      case "5aqMMQ3FlCj":
        Script46();
        break;
      case "5zjLPyegw0f":
        Script47();
        break;
      case "6g1SkxB823X":
        Script48();
        break;
      case "5VkU6Oknqgc":
        Script49();
        break;
      case "5wayxWyHTzh":
        Script50();
        break;
      case "60858E2rJiB":
        Script51();
        break;
      case "5kMLEaxvpju":
        Script52();
        break;
      case "5wjRfPMU1e5":
        Script53();
        break;
      case "6UpP0AvJbyu":
        Script54();
        break;
      case "5u5nCLbXXa0":
        Script55();
        break;
      case "6B49V7LYIi8":
        Script56();
        break;
      case "5hIesB25GVC":
        Script57();
        break;
      case "64tNJhvvTsm":
        Script58();
        break;
      case "6i6iggA51gO":
        Script59();
        break;
      case "63n6UrOrkw9":
        Script60();
        break;
      case "5gE0oqXYUtI":
        Script61();
        break;
      case "6VreJACYXZD":
        Script62();
        break;
      case "5X2uuwfKxn2":
        Script63();
        break;
      case "65hDgtYYAhw":
        Script64();
        break;
      case "6KH5x8XD9P1":
        Script65();
        break;
      case "6bRSF9NQAcx":
        Script66();
        break;
      case "6QQjv46IOd8":
        Script67();
        break;
      case "5j7o3FLU4zt":
        Script68();
        break;
      case "6fPXrOIstHb":
        Script69();
        break;
      case "6YYle62niBY":
        Script70();
        break;
      case "68fhxXsYdsf":
        Script71();
        break;
      case "5zxZvpvJonB":
        Script72();
        break;
      case "5Y0OKtJ7oWZ":
        Script73();
        break;
      case "5ZVZLuu9kyo":
        Script74();
        break;
      case "681RGo5eZLX":
        Script75();
        break;
      case "65CeXiXx3B9":
        Script76();
        break;
      case "6U8Etlr17Wv":
        Script77();
        break;
      case "5flzyt8TGya":
        Script78();
        break;
      case "6LFertNZBpE":
        Script79();
        break;
      case "5ghaxeKdepn":
        Script80();
        break;
      case "5zKuES6DJ9v":
        Script81();
        break;
      case "60ZFtpmLaNS":
        Script82();
        break;
      case "6JF2jTgOSLd":
        Script83();
        break;
      case "6hrcJmVtDwv":
        Script84();
        break;
      case "6JsolxmiJJ1":
        Script85();
        break;
      case "6p3JjAfYEds":
        Script86();
        break;
      case "5sthE7IDmR2":
        Script87();
        break;
      case "67cwQXw7i5k":
        Script88();
        break;
      case "6VENxKTWDCi":
        Script89();
        break;
      case "6mDGbe6KiRw":
        Script90();
        break;
      case "61Y113z64Gq":
        Script91();
        break;
      case "6JubWBTB8yq":
        Script92();
        break;
      case "68Q0seASk6X":
        Script93();
        break;
      case "6KdDbnpK6g0":
        Script94();
        break;
      case "6CQDAxoVdzy":
        Script95();
        break;
      case "68cRG7SNdub":
        Script96();
        break;
      case "6rbo6McnFQd":
        Script97();
        break;
      case "5iXG4DZXqgt":
        Script98();
        break;
      case "5kHqe6qH33V":
        Script99();
        break;
      case "6ZisCJ7BPBS":
        Script100();
        break;
      case "6SH0cYbUwi2":
        Script101();
        break;
      case "60AlHOdYVWp":
        Script102();
        break;
      case "6GdSw6GKYmJ":
        Script103();
        break;
      case "69oXGOhPP1E":
        Script104();
        break;
      case "6d7IYmULu6v":
        Script105();
        break;
      case "6HOwtkEoK5I":
        Script106();
        break;
      case "6YAtBsAi650":
        Script107();
        break;
      case "6O7Rv0ZueLo":
        Script108();
        break;
      case "5fTeR23h9Nn":
        Script109();
        break;
      case "5bIKcPKC155":
        Script110();
        break;
      case "6454NoKKs24":
        Script111();
        break;
      case "689rDiz7EZx":
        Script112();
        break;
      case "66e1E1DEFXR":
        Script113();
        break;
      case "6eoYufv8l9W":
        Script114();
        break;
      case "5xEc67gAlUE":
        Script115();
        break;
      case "6lHOekMBU0G":
        Script116();
        break;
      case "6ORYkvnk3Yw":
        Script117();
        break;
      case "60yOnUlLkw3":
        Script118();
        break;
      case "6NqfSRniIpK":
        Script119();
        break;
      case "5vRo8E3B9YN":
        Script120();
        break;
      case "6d11yXJOg3V":
        Script121();
        break;
      case "5s18QAtXVt1":
        Script122();
        break;
      case "6nMiRSPQEv6":
        Script123();
        break;
      case "5blj1Ecbc5B":
        Script124();
        break;
      case "60DesYRl6sK":
        Script125();
        break;
      case "5Wri11MymPF":
        Script126();
        break;
      case "5s0UVHAwUAn":
        Script127();
        break;
      case "5lgAUzMBo0c":
        Script128();
        break;
      case "5XuKRMpndDh":
        Script129();
        break;
      case "6e73UkUWG51":
        Script130();
        break;
      case "67DjcqwNRJM":
        Script131();
        break;
      case "5yLytmUSMus":
        Script132();
        break;
      case "6Dj2zDu8kuo":
        Script133();
        break;
      case "6ZpWiZHr9Dg":
        Script134();
        break;
      case "6QWuIZroG7q":
        Script135();
        break;
      case "5vpfxnMfuqU":
        Script136();
        break;
      case "5Yn464aYXn7":
        Script137();
        break;
      case "6i7wzrsnfNj":
        Script138();
        break;
      case "6h6YyDmliHQ":
        Script139();
        break;
      case "6f5E2IEijHH":
        Script140();
        break;
      case "5odTNG2FuiZ":
        Script141();
        break;
      case "5Zrl7kXpcY2":
        Script142();
        break;
      case "6D2ouePrFW6":
        Script143();
        break;
      case "5wCPZCb5aW5":
        Script144();
        break;
      case "5yi0SWhEmz9":
        Script145();
        break;
      case "5z76e1IaWmg":
        Script146();
        break;
      case "6LlgTONfxni":
        Script147();
        break;
      case "6E8OKqMQS5C":
        Script148();
        break;
      case "5nAgUugmwXU":
        Script149();
        break;
      case "66CL3BMS1oq":
        Script150();
        break;
      case "5npVzKiKf5c":
        Script151();
        break;
      case "5aqn0xxtXwY":
        Script152();
        break;
      case "6erCwHeWU9b":
        Script153();
        break;
      case "5tZSYUPcswN":
        Script154();
        break;
      case "6WHQZAFdME3":
        Script155();
        break;
      case "6k5pJXQTceM":
        Script156();
        break;
      case "6aFxEIO5M4h":
        Script157();
        break;
      case "5rkIeat60VU":
        Script158();
        break;
      case "6oY040EmeiH":
        Script159();
        break;
      case "6GxPLYPp4n8":
        Script160();
        break;
      case "5zpgzB5FSCQ":
        Script161();
        break;
      case "5bfi4LvT72G":
        Script162();
        break;
      case "6rGSoHsErS8":
        Script163();
        break;
      case "6HHNuLgG8O3":
        Script164();
        break;
      case "6EhDBOQ8Xk7":
        Script165();
        break;
      case "5VwqeZTtYEa":
        Script166();
        break;
      case "6Ht6Vg6jdUA":
        Script167();
        break;
      case "6nTQgz03Ytj":
        Script168();
        break;
      case "5ehT5HV5z05":
        Script169();
        break;
      case "6XHHOEpoRLF":
        Script170();
        break;
      case "6iJezGy8W0L":
        Script171();
        break;
      case "5YQXpfY5bLB":
        Script172();
        break;
      case "6P6MVtwoXkU":
        Script173();
        break;
      case "5mYEGgw13hn":
        Script174();
        break;
      case "5hJ35foVUpW":
        Script175();
        break;
      case "6fvvEhivm5L":
        Script176();
        break;
      case "5xbrEu3ZstD":
        Script177();
        break;
      case "62iL4oMlm2Z":
        Script178();
        break;
      case "6BJABsQn3JJ":
        Script179();
        break;
      case "6ZwBqRkFo2H":
        Script180();
        break;
      case "6PzhclghhZC":
        Script181();
        break;
      case "6X2bkMb2riu":
        Script182();
        break;
      case "5lbj7SxVvEX":
        Script183();
        break;
      case "5aW7UM1oh3g":
        Script184();
        break;
      case "6bX5ShVUlVm":
        Script185();
        break;
      case "5u4YpebPWB2":
        Script186();
        break;
      case "6JRKZksZvht":
        Script187();
        break;
      case "64gXrR4KLEi":
        Script188();
        break;
      case "5XEL7qnfSH5":
        Script189();
        break;
      case "6OV14iEAcJD":
        Script190();
        break;
      case "6cC1WeAnvbP":
        Script191();
        break;
      case "5VNaLLNgvbi":
        Script192();
        break;
      case "5gbrjwHTAZp":
        Script193();
        break;
      case "5ymDXlEFzLM":
        Script194();
        break;
      case "6a3jNExknd0":
        Script195();
        break;
      case "5dctPD69LEZ":
        Script196();
        break;
      case "6g7Cm4VsyKO":
        Script197();
        break;
      case "6kWfwntQKqV":
        Script198();
        break;
      case "6Dqd3SmJ0EN":
        Script199();
        break;
      case "6Eyqo5IsrEb":
        Script200();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
var update = player.update;
var pointerX = player.pointerX;
var pointerY = player.pointerY;
var showPointer = player.showPointer;
var hidePointer = player.hidePointer;
var slideWidth = player.slideWidth;
var slideHeight = player.slideHeight;
window.Script1 = function()
{
  const target = object('5lWjAOt6I2q');
const duration = 750;
const easing = 'ease-out';
const id = '6ceSNY8rzkS';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script2 = function()
{
  const target = object('6UbOsX2CgAq');
const duration = 750;
const easing = 'ease-out';
const id = '6JOx2gbT4Io';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script3 = function()
{
  const target = object('6qqfgcaGZ45');
const duration = 750;
const easing = 'ease-out';
const id = '6ZilVfgX9DA';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script4 = function()
{
  const target = object('6QFh3TZzdty');
const duration = 750;
const easing = 'ease-out';
const id = '6Ali5Vrviyf';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script5 = function()
{
  const target = object('6fCSpa9LPkf');
const duration = 750;
const easing = 'ease-out';
const id = '6ZHfuos6QPX';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script6 = function()
{
  const target = object('5yFytgk5ppp');
const duration = 750;
const easing = 'ease-out';
const id = '5qU6aavdZFe';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script7 = function()
{
  const target = object('6RXc9Lir7NJ');
const duration = 750;
const easing = 'ease-out';
const id = '6KviKEcNJ1x';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script8 = function()
{
  const target = object('68fi63RCOrZ');
const duration = 750;
const easing = 'ease-out';
const id = '63BuUXju3x5';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script9 = function()
{
  const target = object('5i5t05JqqRF');
const duration = 750;
const easing = 'ease-out';
const id = '6bP4r8D8J6c';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script10 = function()
{
  const target = object('6peXjCA38rc');
const duration = 750;
const easing = 'ease-out';
const id = '682BH5MFkya';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script11 = function()
{
  const target = object('6GVi3ebpISR');
const duration = 750;
const easing = 'ease-out';
const id = '6EFpNRpXoK0';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script12 = function()
{
  const target = object('5YVYARmUYUE');
const duration = 750;
const easing = 'ease-out';
const id = '5s3txdNKyTq';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script13 = function()
{
  const target = object('5zoLHMhDiHW');
const duration = 750;
const easing = 'ease-out';
const id = '6huUHQssbAx';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script14 = function()
{
  const target = object('634rNs2EEfO');
const duration = 750;
const easing = 'ease-out';
const id = '6Gjoqw4HUgl';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script15 = function()
{
  const target = object('5yw0tQGLm6o');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script16 = function()
{
  const target = object('5yw0tQGLm6o');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script17 = function()
{
  const target = object('6evfk4Dbi2v');
const duration = 750;
const easing = 'ease-out';
const id = '65CGoSqFi0k';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script18 = function()
{
  const target = object('5yw0tQGLm6o');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script19 = function()
{
  const target = object('6pa4hgYm1sf');
const duration = 750;
const easing = 'ease-out';
const id = '6FdyfEZ7nzl';
const teeterAmount = 2;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script20 = function()
{
  const target = object('5fdxvDFFo4H');
const duration = 750;
const easing = 'ease-out';
const id = '6V5G7ePKIWG';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script21 = function()
{
  const target = object('650IKobOfnN');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script22 = function()
{
  const target = object('5lpWHqNaE69');
const duration = 750;
const easing = 'ease-out';
const id = '6VCV0MhgAK2';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script23 = function()
{
  const target = object('5XgIvX29qiI');
const duration = 750;
const easing = 'ease-out';
const id = '5pjMyTbBf12';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script24 = function()
{
  const target = object('5aMSlYkIfrP');
const duration = 1500;
const easing = 'ease-out';
const id = '6UModvtg3Sn';
const shakeAmount = 5;
player.addForTriggers(
id,
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script25 = function()
{
  const target = object('5aMSlYkIfrP');
const duration = 1500;
const easing = 'ease-out';
const id = '6UModvtg3Sn';
const shakeAmount = 5;
player.addForTriggers(
id,
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script26 = function()
{
  const target = object('6J73Gd6X6Eu');
const duration = 500;
const easing = 'ease-out';
const id = '5dy2CyJ8ee1';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script27 = function()
{
  const target = object('6J73Gd6X6Eu');
const duration = 500;
const easing = 'ease-out';
const id = '5dy2CyJ8ee1';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script28 = function()
{
  const target = object('5XgIvX29qiI');
const duration = 750;
const easing = 'ease-out';
const id = '5pjMyTbBf12';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script29 = function()
{
  const target = object('6nOgPtJGEAR');
const duration = 1500;
const easing = 'ease-out';
const id = '5X7PWJMa0MF';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script30 = function()
{
  const target = object('6nOgPtJGEAR');
const duration = 1500;
const easing = 'ease-out';
const id = '5X7PWJMa0MF';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script31 = function()
{
  const target = object('5WKlXPc1Mzz');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script32 = function()
{
  const target = object('5WKlXPc1Mzz');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script33 = function()
{
  const target = object('5otvINpgfdQ');
const duration = 750;
const easing = 'ease-out';
const id = '65CGoSqFi0k';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script34 = function()
{
  const target = object('5WKlXPc1Mzz');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script35 = function()
{
  const target = object('693CqRk47mq');
const duration = 750;
const easing = 'ease-out';
const id = '6FdyfEZ7nzl';
const teeterAmount = 2;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script36 = function()
{
  const target = object('6exCdJQDiZ1');
const duration = 750;
const easing = 'ease-out';
const id = '6V5G7ePKIWG';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script37 = function()
{
  const target = object('650IKobOfnN');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script38 = function()
{
  const target = object('5lpWHqNaE69');
const duration = 750;
const easing = 'ease-out';
const id = '6VCV0MhgAK2';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script39 = function()
{
  const target = object('5vr4bkWM6R2');
const duration = 750;
const easing = 'ease-out';
const id = '5pjMyTbBf12';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script40 = function()
{
  const target = object('5jP1hgQtOZ3');
const duration = 1500;
const easing = 'ease-out';
const id = '6UModvtg3Sn';
const shakeAmount = 5;
player.addForTriggers(
id,
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script41 = function()
{
  const target = object('5jP1hgQtOZ3');
const duration = 1500;
const easing = 'ease-out';
const id = '6UModvtg3Sn';
const shakeAmount = 5;
player.addForTriggers(
id,
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script42 = function()
{
  const target = object('6M9fvGOpEsp');
const duration = 500;
const easing = 'ease-out';
const id = '5dy2CyJ8ee1';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script43 = function()
{
  const target = object('6M9fvGOpEsp');
const duration = 500;
const easing = 'ease-out';
const id = '5dy2CyJ8ee1';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script44 = function()
{
  const target = object('5vr4bkWM6R2');
const duration = 750;
const easing = 'ease-out';
const id = '5pjMyTbBf12';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script45 = function()
{
  const target = object('6nv7QRXhT2r');
const duration = 1500;
const easing = 'ease-out';
const id = '5X7PWJMa0MF';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script46 = function()
{
  const target = object('6nv7QRXhT2r');
const duration = 1500;
const easing = 'ease-out';
const id = '5X7PWJMa0MF';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script47 = function()
{
  const target = object('650IKobOfnN');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script48 = function()
{
  const target = object('650IKobOfnN');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script49 = function()
{
  const target = object('650IKobOfnN');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script50 = function()
{
  const target = object('5lpWHqNaE69');
const duration = 750;
const easing = 'ease-out';
const id = '6VCV0MhgAK2';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script51 = function()
{
  const target = object('6HzxnE1II41');
const duration = 750;
const easing = 'ease-out';
const id = '6FdyfEZ7nzl';
const teeterAmount = 2;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script52 = function()
{
  const target = object('6fkeOKT9u3q');
const duration = 750;
const easing = 'ease-out';
const id = '6V5G7ePKIWG';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script53 = function()
{
  const target = object('650IKobOfnN');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script54 = function()
{
  const target = object('5lpWHqNaE69');
const duration = 750;
const easing = 'ease-out';
const id = '6VCV0MhgAK2';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script55 = function()
{
  const target = object('5ZyoWxoJeMq');
const duration = 750;
const easing = 'ease-out';
const id = '5pjMyTbBf12';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script56 = function()
{
  const target = object('6dLpSNFUqmv');
const duration = 1500;
const easing = 'ease-out';
const id = '6UModvtg3Sn';
const shakeAmount = 5;
player.addForTriggers(
id,
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script57 = function()
{
  const target = object('6dLpSNFUqmv');
const duration = 1500;
const easing = 'ease-out';
const id = '6UModvtg3Sn';
const shakeAmount = 5;
player.addForTriggers(
id,
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script58 = function()
{
  const target = object('5ZyoWxoJeMq');
const duration = 750;
const easing = 'ease-out';
const id = '5pjMyTbBf12';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script59 = function()
{
  const target = object('6CLEBBRWiZ0');
const duration = 1500;
const easing = 'ease-out';
const id = '5X7PWJMa0MF';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script60 = function()
{
  const target = object('6CLEBBRWiZ0');
const duration = 1500;
const easing = 'ease-out';
const id = '5X7PWJMa0MF';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script61 = function()
{
  const target = object('5tqxjhQ4KsK');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script62 = function()
{
  const target = object('5tqxjhQ4KsK');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script63 = function()
{
  const target = object('6ZsOEO4ERWL');
const duration = 750;
const easing = 'ease-out';
const id = '64kQc9ptW6l';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script64 = function()
{
  const target = object('5tqxjhQ4KsK');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script65 = function()
{
  const target = object('5XoF5pnFzVn');
const duration = 750;
const easing = 'ease-out';
const id = '6FdyfEZ7nzl';
const teeterAmount = 2;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script66 = function()
{
  const target = object('6cXWT6QYhaD');
const duration = 750;
const easing = 'ease-out';
const id = '6V5G7ePKIWG';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script67 = function()
{
  const target = object('6bBMdxrQH2H');
const duration = 750;
const easing = 'ease-out';
const id = '5pjMyTbBf12';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script68 = function()
{
  const target = object('5X9hDTLr2GZ');
const duration = 1500;
const easing = 'ease-out';
const id = '6UModvtg3Sn';
const shakeAmount = 5;
player.addForTriggers(
id,
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script69 = function()
{
  const target = object('5X9hDTLr2GZ');
const duration = 1500;
const easing = 'ease-out';
const id = '6UModvtg3Sn';
const shakeAmount = 5;
player.addForTriggers(
id,
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script70 = function()
{
  const target = object('5oLKJ5SYCvU');
const duration = 500;
const easing = 'ease-out';
const id = '5dy2CyJ8ee1';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script71 = function()
{
  const target = object('5oLKJ5SYCvU');
const duration = 500;
const easing = 'ease-out';
const id = '5dy2CyJ8ee1';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script72 = function()
{
  const target = object('6bBMdxrQH2H');
const duration = 750;
const easing = 'ease-out';
const id = '5pjMyTbBf12';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script73 = function()
{
  const target = object('6clJmt0VLo9');
const duration = 1500;
const easing = 'ease-out';
const id = '5X7PWJMa0MF';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script74 = function()
{
  const target = object('6clJmt0VLo9');
const duration = 1500;
const easing = 'ease-out';
const id = '5X7PWJMa0MF';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script75 = function()
{
  const target = object('6EVgSRypk1d');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script76 = function()
{
  const target = object('6EVgSRypk1d');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script77 = function()
{
  const target = object('6kOH6TCz8MV');
const duration = 750;
const easing = 'ease-out';
const id = '65CGoSqFi0k';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script78 = function()
{
  const target = object('6EVgSRypk1d');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script79 = function()
{
  const target = object('5VohaTTOaXI');
const duration = 750;
const easing = 'ease-out';
const id = '6FdyfEZ7nzl';
const teeterAmount = 2;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script80 = function()
{
  const target = object('5vvcKhgYA7g');
const duration = 750;
const easing = 'ease-out';
const id = '6V5G7ePKIWG';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script81 = function()
{
  const target = object('5w9N7SdIHwY');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script82 = function()
{
  const target = object('6a2INlSjCVz');
const duration = 750;
const easing = 'ease-out';
const id = '6VCV0MhgAK2';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script83 = function()
{
  const target = object('6AUuRq53qLz');
const duration = 750;
const easing = 'ease-out';
const id = '5pjMyTbBf12';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script84 = function()
{
  const target = object('6p5cHrs12nQ');
const duration = 1500;
const easing = 'ease-out';
const id = '6UModvtg3Sn';
const shakeAmount = 5;
player.addForTriggers(
id,
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script85 = function()
{
  const target = object('6p5cHrs12nQ');
const duration = 1500;
const easing = 'ease-out';
const id = '6UModvtg3Sn';
const shakeAmount = 5;
player.addForTriggers(
id,
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script86 = function()
{
  const target = object('6AdkXDkdBDx');
const duration = 500;
const easing = 'ease-out';
const id = '5dy2CyJ8ee1';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script87 = function()
{
  const target = object('6AdkXDkdBDx');
const duration = 500;
const easing = 'ease-out';
const id = '5dy2CyJ8ee1';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script88 = function()
{
  const target = object('6AUuRq53qLz');
const duration = 750;
const easing = 'ease-out';
const id = '5pjMyTbBf12';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script89 = function()
{
  const target = object('5jU7CQRJqHM');
const duration = 1500;
const easing = 'ease-out';
const id = '5X7PWJMa0MF';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script90 = function()
{
  const target = object('5jU7CQRJqHM');
const duration = 1500;
const easing = 'ease-out';
const id = '5X7PWJMa0MF';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script91 = function()
{
  const target = object('5w9N7SdIHwY');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script92 = function()
{
  const target = object('5w9N7SdIHwY');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script93 = function()
{
  const target = object('5w9N7SdIHwY');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script94 = function()
{
  const target = object('6a2INlSjCVz');
const duration = 750;
const easing = 'ease-out';
const id = '6VCV0MhgAK2';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script95 = function()
{
  const target = object('6BBUyx7TKFW');
const duration = 750;
const easing = 'ease-out';
const id = '6FdyfEZ7nzl';
const teeterAmount = 2;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script96 = function()
{
  const target = object('5VurNOj4cbR');
const duration = 750;
const easing = 'ease-out';
const id = '6V5G7ePKIWG';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script97 = function()
{
  const target = object('5w9N7SdIHwY');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script98 = function()
{
  const target = object('6a2INlSjCVz');
const duration = 750;
const easing = 'ease-out';
const id = '6VCV0MhgAK2';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script99 = function()
{
  const target = object('6kung5J4O8C');
const duration = 750;
const easing = 'ease-out';
const id = '5pjMyTbBf12';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script100 = function()
{
  const target = object('6121i1tpLvH');
const duration = 1500;
const easing = 'ease-out';
const id = '6UModvtg3Sn';
const shakeAmount = 5;
player.addForTriggers(
id,
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script101 = function()
{
  const target = object('6121i1tpLvH');
const duration = 1500;
const easing = 'ease-out';
const id = '6UModvtg3Sn';
const shakeAmount = 5;
player.addForTriggers(
id,
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script102 = function()
{
  const target = object('6kung5J4O8C');
const duration = 750;
const easing = 'ease-out';
const id = '5pjMyTbBf12';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script103 = function()
{
  const target = object('6On0hEhtKLR');
const duration = 1500;
const easing = 'ease-out';
const id = '5X7PWJMa0MF';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script104 = function()
{
  const target = object('6On0hEhtKLR');
const duration = 1500;
const easing = 'ease-out';
const id = '5X7PWJMa0MF';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script105 = function()
{
  const target = object('5wZVYJqBHeb');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script106 = function()
{
  const target = object('5wZVYJqBHeb');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script107 = function()
{
  const target = object('665N5XpfEXA');
const duration = 750;
const easing = 'ease-out';
const id = '64kQc9ptW6l';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script108 = function()
{
  const target = object('5wZVYJqBHeb');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script109 = function()
{
  const target = object('65cMCLGsndU');
const duration = 750;
const easing = 'ease-out';
const id = '6FdyfEZ7nzl';
const teeterAmount = 2;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script110 = function()
{
  const target = object('63JbAcUR9Ow');
const duration = 750;
const easing = 'ease-out';
const id = '6V5G7ePKIWG';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script111 = function()
{
  const target = object('5qMpxwrN9SH');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script112 = function()
{
  const target = object('5WB6BKfRhrO');
const duration = 750;
const easing = 'ease-out';
const id = '6VCV0MhgAK2';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script113 = function()
{
  const target = object('6iLGnjnz0Sn');
const duration = 750;
const easing = 'ease-out';
const id = '5pjMyTbBf12';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script114 = function()
{
  const target = object('6Ul7pxMVh2O');
const duration = 1500;
const easing = 'ease-out';
const id = '6UModvtg3Sn';
const shakeAmount = 5;
player.addForTriggers(
id,
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script115 = function()
{
  const target = object('6Ul7pxMVh2O');
const duration = 1500;
const easing = 'ease-out';
const id = '6UModvtg3Sn';
const shakeAmount = 5;
player.addForTriggers(
id,
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script116 = function()
{
  const target = object('6IpTTjE192G');
const duration = 500;
const easing = 'ease-out';
const id = '5dy2CyJ8ee1';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script117 = function()
{
  const target = object('6IpTTjE192G');
const duration = 500;
const easing = 'ease-out';
const id = '5dy2CyJ8ee1';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script118 = function()
{
  const target = object('6iLGnjnz0Sn');
const duration = 750;
const easing = 'ease-out';
const id = '5pjMyTbBf12';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script119 = function()
{
  const target = object('6RJ6N4mMRkW');
const duration = 1500;
const easing = 'ease-out';
const id = '5X7PWJMa0MF';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script120 = function()
{
  const target = object('6RJ6N4mMRkW');
const duration = 1500;
const easing = 'ease-out';
const id = '5X7PWJMa0MF';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script121 = function()
{
  const target = object('6Za6IKGbL6W');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script122 = function()
{
  const target = object('6Za6IKGbL6W');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script123 = function()
{
  const target = object('5zas7pobMWd');
const duration = 750;
const easing = 'ease-out';
const id = '65CGoSqFi0k';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script124 = function()
{
  const target = object('6Za6IKGbL6W');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script125 = function()
{
  const target = object('5uUrjri6IK6');
const duration = 750;
const easing = 'ease-out';
const id = '6FdyfEZ7nzl';
const teeterAmount = 2;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script126 = function()
{
  const target = object('5VmKs8RJqSu');
const duration = 750;
const easing = 'ease-out';
const id = '6V5G7ePKIWG';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script127 = function()
{
  const target = object('5qMpxwrN9SH');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script128 = function()
{
  const target = object('5WB6BKfRhrO');
const duration = 750;
const easing = 'ease-out';
const id = '6VCV0MhgAK2';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script129 = function()
{
  const target = object('6aUGvdypzeE');
const duration = 750;
const easing = 'ease-out';
const id = '5pjMyTbBf12';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script130 = function()
{
  const target = object('5vNeP9kT1C7');
const duration = 1500;
const easing = 'ease-out';
const id = '6UModvtg3Sn';
const shakeAmount = 5;
player.addForTriggers(
id,
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script131 = function()
{
  const target = object('5vNeP9kT1C7');
const duration = 1500;
const easing = 'ease-out';
const id = '6UModvtg3Sn';
const shakeAmount = 5;
player.addForTriggers(
id,
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script132 = function()
{
  const target = object('5szMso2hUOx');
const duration = 500;
const easing = 'ease-out';
const id = '5dy2CyJ8ee1';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script133 = function()
{
  const target = object('5szMso2hUOx');
const duration = 500;
const easing = 'ease-out';
const id = '5dy2CyJ8ee1';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script134 = function()
{
  const target = object('6aUGvdypzeE');
const duration = 750;
const easing = 'ease-out';
const id = '5pjMyTbBf12';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script135 = function()
{
  const target = object('6OjchF3Jp6y');
const duration = 1500;
const easing = 'ease-out';
const id = '5X7PWJMa0MF';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script136 = function()
{
  const target = object('6OjchF3Jp6y');
const duration = 1500;
const easing = 'ease-out';
const id = '5X7PWJMa0MF';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script137 = function()
{
  const target = object('5qMpxwrN9SH');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script138 = function()
{
  const target = object('5qMpxwrN9SH');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script139 = function()
{
  const target = object('5qMpxwrN9SH');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script140 = function()
{
  const target = object('5WB6BKfRhrO');
const duration = 750;
const easing = 'ease-out';
const id = '6VCV0MhgAK2';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script141 = function()
{
  const target = object('5zbpIARCI9X');
const duration = 750;
const easing = 'ease-out';
const id = '6FdyfEZ7nzl';
const teeterAmount = 2;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script142 = function()
{
  const target = object('69XvgeCirk3');
const duration = 750;
const easing = 'ease-out';
const id = '6V5G7ePKIWG';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script143 = function()
{
  const target = object('5qMpxwrN9SH');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script144 = function()
{
  const target = object('5WB6BKfRhrO');
const duration = 750;
const easing = 'ease-out';
const id = '6VCV0MhgAK2';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script145 = function()
{
  const target = object('6r9GbBpSyt3');
const duration = 750;
const easing = 'ease-out';
const id = '5pjMyTbBf12';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script146 = function()
{
  const target = object('66daLeOYADf');
const duration = 1500;
const easing = 'ease-out';
const id = '6UModvtg3Sn';
const shakeAmount = 5;
player.addForTriggers(
id,
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script147 = function()
{
  const target = object('66daLeOYADf');
const duration = 1500;
const easing = 'ease-out';
const id = '6UModvtg3Sn';
const shakeAmount = 5;
player.addForTriggers(
id,
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script148 = function()
{
  const target = object('6r9GbBpSyt3');
const duration = 750;
const easing = 'ease-out';
const id = '5pjMyTbBf12';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script149 = function()
{
  const target = object('6VSgvmUoSOx');
const duration = 1500;
const easing = 'ease-out';
const id = '5X7PWJMa0MF';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script150 = function()
{
  const target = object('6VSgvmUoSOx');
const duration = 1500;
const easing = 'ease-out';
const id = '5X7PWJMa0MF';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script151 = function()
{
  const target = object('6AAFw5pJFIq');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script152 = function()
{
  const target = object('6AAFw5pJFIq');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script153 = function()
{
  const target = object('6Jyqn3FigUl');
const duration = 750;
const easing = 'ease-out';
const id = '64kQc9ptW6l';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script154 = function()
{
  const target = object('6AAFw5pJFIq');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script155 = function()
{
  const target = object('5VlcvMPSxXe');
const duration = 750;
const easing = 'ease-out';
const id = '6FdyfEZ7nzl';
const teeterAmount = 2;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script156 = function()
{
  const target = object('5Ztkh06lxam');
const duration = 750;
const easing = 'ease-out';
const id = '6V5G7ePKIWG';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script157 = function()
{
  const target = object('5YsBgOIcVVy');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script158 = function()
{
  const target = object('62eLRG2B5EN');
const duration = 750;
const easing = 'ease-out';
const id = '6VCV0MhgAK2';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script159 = function()
{
  const target = object('6YK2PywdF4t');
const duration = 750;
const easing = 'ease-out';
const id = '5pjMyTbBf12';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script160 = function()
{
  const target = object('6oen32Q5IHM');
const duration = 1500;
const easing = 'ease-out';
const id = '6UModvtg3Sn';
const shakeAmount = 5;
player.addForTriggers(
id,
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script161 = function()
{
  const target = object('6oen32Q5IHM');
const duration = 1500;
const easing = 'ease-out';
const id = '6UModvtg3Sn';
const shakeAmount = 5;
player.addForTriggers(
id,
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script162 = function()
{
  const target = object('6IDixsPo5h3');
const duration = 500;
const easing = 'ease-out';
const id = '5dy2CyJ8ee1';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script163 = function()
{
  const target = object('6IDixsPo5h3');
const duration = 500;
const easing = 'ease-out';
const id = '5dy2CyJ8ee1';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script164 = function()
{
  const target = object('6YK2PywdF4t');
const duration = 750;
const easing = 'ease-out';
const id = '5pjMyTbBf12';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script165 = function()
{
  const target = object('5vOkTkU1ESg');
const duration = 1500;
const easing = 'ease-out';
const id = '5X7PWJMa0MF';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script166 = function()
{
  const target = object('5vOkTkU1ESg');
const duration = 1500;
const easing = 'ease-out';
const id = '5X7PWJMa0MF';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script167 = function()
{
  const target = object('6nbIhwHkDIm');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script168 = function()
{
  const target = object('6nbIhwHkDIm');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script169 = function()
{
  const target = object('5hEK6PWv5yj');
const duration = 750;
const easing = 'ease-out';
const id = '65CGoSqFi0k';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script170 = function()
{
  const target = object('6nbIhwHkDIm');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script171 = function()
{
  const target = object('6JfGEZ1eCWX');
const duration = 750;
const easing = 'ease-out';
const id = '6FdyfEZ7nzl';
const teeterAmount = 2;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script172 = function()
{
  const target = object('6FR7ij8xODY');
const duration = 750;
const easing = 'ease-out';
const id = '6V5G7ePKIWG';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script173 = function()
{
  const target = object('5YsBgOIcVVy');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script174 = function()
{
  const target = object('62eLRG2B5EN');
const duration = 750;
const easing = 'ease-out';
const id = '6VCV0MhgAK2';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script175 = function()
{
  const target = object('6JxMxULGyOP');
const duration = 750;
const easing = 'ease-out';
const id = '5pjMyTbBf12';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script176 = function()
{
  const target = object('6mFjJBIVgj7');
const duration = 1500;
const easing = 'ease-out';
const id = '6UModvtg3Sn';
const shakeAmount = 5;
player.addForTriggers(
id,
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script177 = function()
{
  const target = object('6mFjJBIVgj7');
const duration = 1500;
const easing = 'ease-out';
const id = '6UModvtg3Sn';
const shakeAmount = 5;
player.addForTriggers(
id,
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script178 = function()
{
  const target = object('6I4HjU2IU5Q');
const duration = 500;
const easing = 'ease-out';
const id = '5dy2CyJ8ee1';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script179 = function()
{
  const target = object('6I4HjU2IU5Q');
const duration = 500;
const easing = 'ease-out';
const id = '5dy2CyJ8ee1';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script180 = function()
{
  const target = object('6JxMxULGyOP');
const duration = 750;
const easing = 'ease-out';
const id = '5pjMyTbBf12';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script181 = function()
{
  const target = object('6KDD3zv2SRZ');
const duration = 1500;
const easing = 'ease-out';
const id = '5X7PWJMa0MF';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script182 = function()
{
  const target = object('6KDD3zv2SRZ');
const duration = 1500;
const easing = 'ease-out';
const id = '5X7PWJMa0MF';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script183 = function()
{
  const target = object('5YsBgOIcVVy');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script184 = function()
{
  const target = object('5YsBgOIcVVy');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script185 = function()
{
  const target = object('5YsBgOIcVVy');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script186 = function()
{
  const target = object('62eLRG2B5EN');
const duration = 750;
const easing = 'ease-out';
const id = '6VCV0MhgAK2';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script187 = function()
{
  const target = object('66tEbyfFswl');
const duration = 750;
const easing = 'ease-out';
const id = '6FdyfEZ7nzl';
const teeterAmount = 2;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script188 = function()
{
  const target = object('6Qo2ULCFJMO');
const duration = 750;
const easing = 'ease-out';
const id = '6V5G7ePKIWG';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script189 = function()
{
  const target = object('5YsBgOIcVVy');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script190 = function()
{
  const target = object('62eLRG2B5EN');
const duration = 750;
const easing = 'ease-out';
const id = '6VCV0MhgAK2';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script191 = function()
{
  const target = object('6NtsvIiFlru');
const duration = 750;
const easing = 'ease-out';
const id = '5pjMyTbBf12';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script192 = function()
{
  const target = object('6QvYrMaGtaU');
const duration = 1500;
const easing = 'ease-out';
const id = '6UModvtg3Sn';
const shakeAmount = 5;
player.addForTriggers(
id,
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script193 = function()
{
  const target = object('6QvYrMaGtaU');
const duration = 1500;
const easing = 'ease-out';
const id = '6UModvtg3Sn';
const shakeAmount = 5;
player.addForTriggers(
id,
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script194 = function()
{
  const target = object('6NtsvIiFlru');
const duration = 750;
const easing = 'ease-out';
const id = '5pjMyTbBf12';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script195 = function()
{
  const target = object('5x7XSVOGGKM');
const duration = 1500;
const easing = 'ease-out';
const id = '5X7PWJMa0MF';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script196 = function()
{
  const target = object('5x7XSVOGGKM');
const duration = 1500;
const easing = 'ease-out';
const id = '5X7PWJMa0MF';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script197 = function()
{
  const target = object('642J7MJwpgJ');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script198 = function()
{
  const target = object('642J7MJwpgJ');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script199 = function()
{
  const target = object('6LmQxk7n5Uj');
const duration = 750;
const easing = 'ease-out';
const id = '64kQc9ptW6l';
const teeterAmount = 4;
const signs = ['-', '', '-'];

player.addForTriggers(
id,
target.animate([
{ rotate: '0deg' },
{ rotate: `${signs[0] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[1] + teeterAmount}deg` },
{ rotate: '0deg' },
{ rotate: `${signs[2] + teeterAmount}deg` },
{ rotate: '0deg' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script200 = function()
{
  const target = object('642J7MJwpgJ');
const duration = 1500;
const easing = 'ease-out';
const id = '6iJrE1mg9T0';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

};

# NOAA research source archive

DSC 450 Capstone Project 1, Fall 2026. The four supplied originals are preserved byte-for-byte; figure PNGs were extracted from saved notebook output, not regenerated. See manifest.json for file hashes and cell positions.

## Credits
Matthew Scarpello (data scientist), Andrea Barfield (data wrangler), Hali Sarah Parsons (visualizer/presenter). The two PDFs are collaborative research deliverables. The visualization notebook is Sarah Parsons' work. The modeling-v3 notebook is an exploratory extension, not the exact final model training notebook.

## Interpretation and reproducibility
The final report documents episode-based economic-damage classification and the official comparison scores. The extended notebook uses separate physical-intensity and co-occurrence experiments; it should not be presented as the exact training source for those results. The cleaned input CSV and exact final training workflow were not provided, so the published metrics have not been independently reproduced. Notebook paths may need adapting. Raw source: https://www.ncei.noaa.gov/access/storm-events-database/

## Portfolio publishing
Upload the intact ZIP to downloads/noaa-research-sources.zip in the Portfolio-Repository. The NOAA case study can recognize this expected location and expose the archive download link when present. Review all source files for publication permissions first.
